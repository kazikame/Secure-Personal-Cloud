from django.contrib import admin
from fileserver.models import File

admin.site.register(File);